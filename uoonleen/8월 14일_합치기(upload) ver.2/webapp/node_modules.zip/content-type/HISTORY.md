1.0.2 / 2016-05-09
==================

  * perf: enable strict mode

1.0.1 / 2015-02-13
==================

  * Improve missing `Content-Type` header error message

1.0.0 / 2015-02-01
==================

  * Initial implementation, derived from `media-typer@0.3.0`
